/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 36:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.cancelReservation = exports.updateSongStatus = exports.addSongToRoom = exports.getReservedSongs = void 0;
const dotenv = __importStar(__webpack_require__(818));
const promise_1 = __importDefault(__webpack_require__(498));
dotenv.config();
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
};
const getReservedSongs = async (event) => {
    let connection = null;
    try {
        connection = await promise_1.default.createConnection(dbConfig);
        const { roomId } = event.pathParameters || {};
        if (!roomId) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Missing roomId",
                }),
            };
        }
        const sql = `
        SELECT rs.*, u.user_name as reserved_by
        FROM room_song rs
        JOIN users u ON rs.user_id = u.user_id
        WHERE rs.room_id = ? AND rs.sung = false`;
        const [rows] = await connection.query(sql, [roomId]);
        return {
            statusCode: 200,
            body: JSON.stringify(rows),
        };
    }
    catch (error) {
        console.error("Error fetching reserved songs:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Failed to fetch reserved songs",
            }),
        };
    }
    finally {
        if (connection) {
            await connection.end();
        }
    }
};
exports.getReservedSongs = getReservedSongs;
const addSongToRoom = async (event) => {
    let connection = null;
    try {
        connection = await promise_1.default.createConnection(dbConfig);
        const { roomId } = event.pathParameters || {};
        const body = JSON.parse(event.body || "{}");
        const { user_id, singer, song_name, genre } = body;
        if (!roomId || !user_id || !singer || !song_name) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Missing required parameters",
                }),
            };
        }
        const sql = `
        INSERT INTO room_song (user_id, singer, song_name, room_id, genre)
        VALUES (?, ?, ?, ?, ?)`;
        console.log(user_id, singer, song_name, roomId, genre || null);
        const [result] = await connection.query(sql, [
            user_id,
            singer,
            song_name,
            roomId,
            genre || null,
        ]);
        if (result.affectedRows === 1) {
            return {
                statusCode: 201,
                body: JSON.stringify({
                    message: "Song added to room successfully",
                }),
            };
        }
        else {
            return {
                statusCode: 500,
                body: JSON.stringify({
                    message: "Failed to add song to room",
                }),
            };
        }
    }
    catch (error) {
        console.error("Error adding song to room:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Internal server error",
            }),
        };
    }
    finally {
        if (connection) {
            await connection.end();
        }
    }
};
exports.addSongToRoom = addSongToRoom;
const updateSongStatus = async (event) => {
    let connection = null;
    try {
        connection = await promise_1.default.createConnection(dbConfig);
        const { roomId, songId } = event.pathParameters || {};
        const body = JSON.parse(event.body || "{}");
        const { score, sung } = body;
        if (!roomId || !songId) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Missing songId parameter",
                }),
            };
        }
        let sql = "";
        let values = [];
        if (sung !== undefined) {
            // 클라이언트에서 sung = true만 보낸 경우
            sql = `
          UPDATE room_song
          SET score = ?, sung = ?
          WHERE song_id = ?`;
            values = [score, sung, songId];
        }
        else if (score !== undefined) {
            // 클라이언트에서 score만 보낸 경우
            sql = `
          UPDATE room_song
          SET score = ?
          WHERE song_id = ?`;
            values = [score, songId];
        }
        else {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Invalid request body",
                }),
            };
        }
        const [result] = await connection.query(sql, values);
        if (result.affectedRows === 1) {
            return {
                statusCode: 200,
                body: JSON.stringify({
                    message: "Song status updated successfully",
                }),
            };
        }
        else {
            return {
                statusCode: 500,
                body: JSON.stringify({
                    message: "Failed to update song status",
                }),
            };
        }
    }
    catch (error) {
        console.error("Error updating song status:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Internal server error",
            }),
        };
    }
    finally {
        if (connection) {
            await connection.end();
        }
    }
};
exports.updateSongStatus = updateSongStatus;
const cancelReservation = async (event) => {
    let connection = null;
    try {
        connection = await promise_1.default.createConnection(dbConfig);
        const { roomId, songId } = event.pathParameters || {};
        if (!roomId || !songId) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "Missing songId parameter",
                }),
            };
        }
        // 예약 취소 쿼리
        const sql = `
    DELETE FROM room_song
    WHERE room_id = ? AND song_id = ?`;
        const [result] = await connection.query(sql, [
            roomId,
            songId,
        ]);
        if (result.affectedRows === 1) {
            return {
                statusCode: 200,
                body: JSON.stringify({
                    message: "Reservation canceled successfully",
                }),
            };
        }
        else {
            return {
                statusCode: 404,
                body: JSON.stringify({
                    message: "Song reservation not found",
                }),
            };
        }
    }
    catch (error) {
        console.error("Error canceling reservation:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Internal server error",
            }),
        };
    }
    finally {
        if (connection) {
            await connection.end();
        }
    }
};
exports.cancelReservation = cancelReservation;


/***/ }),

/***/ 818:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 498:
/***/ ((module) => {

module.exports = require("mysql2/promise");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(36);
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;